namespace QuizApp
{
    public class Question
    {
        public string   QuestionText  { get; set; }
        public string   ImageBase64   { get; set; }   // optional — null for text-only questions
        public string[] Options       { get; set; }
        public int      CorrectAnswerIndex { get; set; }
    }
}
