using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace QuizApp
{
    public class ResultForm : Form
    {
        private readonly List<Question> _questions;
        private readonly int[]          _userAnswers;
        private readonly string         _fullName;
        private readonly int            _score;
        private readonly string         _quizTitle;
        private readonly bool           _excelOk;
        private readonly string         _excelErr;
        private readonly int            _timeTaken;

        public ResultForm(List<Question> questions, int[] userAnswers, string fullName,
                          int score, string quizTitle, bool excelOk, string excelErr, int timeTaken)
        {
            _questions   = questions;
            _userAnswers = userAnswers;
            _fullName    = fullName;
            _score       = score;
            _quizTitle   = quizTitle;
            _excelOk     = excelOk;
            _excelErr    = excelErr;
            _timeTaken   = timeTaken;
            BuildUI();
        }

        private void BuildUI()
        {
            int    total = _questions.Count;
            double pct   = total > 0 ? (double)_score / total * 100 : 0;
            string time  = ExcelScoreWriter.FormatTime(_timeTaken);

            Text            = "Results — " + _quizTitle;
            Size            = new Size(700, 700);
            MinimumSize     = new Size(700, 700);
            MaximumSize     = new Size(700, 700);
            StartPosition   = FormStartPosition.CenterScreen;
            BackColor       = Color.FromArgb(245, 247, 250);
            Font            = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox     = false;

            Color headerColor = pct >= 80 ? Color.FromArgb(30, 120, 70)
                              : pct >= 60 ? Color.FromArgb(160, 100, 20)
                                          : Color.FromArgb(180, 40, 40);
            string grade = pct >= 80 ? "Excellent  🏆"
                         : pct >= 60 ? "Good  👍"
                         : pct >= 40 ? "Average" : "Needs Improvement";

            // ── Header ─────────────────────────────────────────────────
            var pnlHeader = new Panel { Dock = DockStyle.Top, Height = 160,
                                        BackColor = headerColor };

            void Lbl(string text, Font font, Color fg, Point loc, Size sz, Control parent)
            {
                parent.Controls.Add(new Label { Text=text, Font=font, ForeColor=fg,
                    Location=loc, Size=sz, TextAlign=ContentAlignment.MiddleLeft });
            }

            Lbl("Quiz Complete!", new Font("Segoe UI",16f,FontStyle.Bold),
                Color.White, new Point(20,18), new Size(390,34), pnlHeader);
            Lbl("👤  " + _fullName, new Font("Segoe UI",9.5f),
                Color.FromArgb(210,240,210), new Point(22,56), new Size(390,22), pnlHeader);
            Lbl($"{grade}   •   ⏱ {time}", new Font("Segoe UI",10.5f,FontStyle.Bold),
                Color.White, new Point(22,82), new Size(450,24), pnlHeader);
            Lbl(_excelOk ? "✔  Score saved to shared drive (master + dashboard copy)."
                         : "⚠  Could not save: " + _excelErr,
                new Font("Segoe UI",8.5f),
                _excelOk ? Color.FromArgb(180,255,180) : Color.Yellow,
                new Point(22,122), new Size(500,22), pnlHeader);

            // Score box
            var pnlBox = new Panel { Location=new Point(516,16), Size=new Size(152,126),
                                     BackColor=Color.FromArgb(0,0,0,40) };
            pnlBox.Controls.Add(new Label { Text=$"{_score} / {total}",
                ForeColor=Color.White, Font=new Font("Segoe UI",26f,FontStyle.Bold),
                Location=new Point(0,14), Size=new Size(152,54),
                TextAlign=ContentAlignment.MiddleCenter });
            pnlBox.Controls.Add(new Label { Text=$"{pct:F1}%",
                ForeColor=Color.FromArgb(210,255,210), Font=new Font("Segoe UI",13f,FontStyle.Bold),
                Location=new Point(0,70), Size=new Size(152,30),
                TextAlign=ContentAlignment.MiddleCenter });
            pnlHeader.Controls.Add(pnlBox);

            // ── Review header ──────────────────────────────────────────
            int wrong = 0;
            for (int i = 0; i < _questions.Count; i++)
                if (_userAnswers[i] != _questions[i].CorrectAnswerIndex) wrong++;

            var pnlRevHdr = new Panel { Dock=DockStyle.Top, Height=36,
                                        BackColor=Color.FromArgb(232,240,252) };
            pnlRevHdr.Paint += (s,e) =>
            {
                using var p = new System.Drawing.Pen(Color.FromArgb(200,212,228),1);
                e.Graphics.DrawLine(p,0,pnlRevHdr.Height-1,pnlRevHdr.Width,pnlRevHdr.Height-1);
            };
            pnlRevHdr.Controls.Add(new Label
            {
                Text = wrong==0 ? "  ✔  Perfect score — all answers correct!"
                                : $"  📋  Answer Review  —  {wrong} incorrect answer{(wrong>1?"s":"")}",
                ForeColor=Color.FromArgb(41,98,172), Font=new Font("Segoe UI",9.5f,FontStyle.Bold),
                Dock=DockStyle.Fill, TextAlign=ContentAlignment.MiddleLeft
            });

            // ── Footer ─────────────────────────────────────────────────
            var pnlFooter = new Panel { Dock=DockStyle.Bottom, Height=64, BackColor=Color.White };
            pnlFooter.Paint += (s,e) =>
            {
                using var p = new System.Drawing.Pen(Color.FromArgb(200,212,228),1);
                e.Graphics.DrawLine(p,0,0,pnlFooter.Width,0);
            };
            var btnClose = new Button
            {
                Text="Close", Size=new Size(150,40),
                Font=new Font("Segoe UI",10.5f,FontStyle.Bold),
                BackColor=Color.FromArgb(41,98,172), ForeColor=Color.White,
                FlatStyle=FlatStyle.Flat, Cursor=Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize=0;
            btnClose.FlatAppearance.MouseOverBackColor=Color.FromArgb(30,78,140);
            btnClose.Click += (s,e) => Application.Exit();
            pnlFooter.Controls.Add(btnClose);
            pnlFooter.Layout += (s,e) =>
                btnClose.Location = new Point(
                    (pnlFooter.ClientSize.Width - btnClose.Width) / 2,
                    (pnlFooter.ClientSize.Height - btnClose.Height) / 2);

            // ── Scroll review ──────────────────────────────────────────
            var scroll = new Panel
            {
                Dock=DockStyle.Fill, AutoScroll=true,
                BackColor=Color.FromArgb(245,247,250), Padding=new Padding(14,8,14,8)
            };

            int y = 8;
            string[] L = { "A","B","C","D" };
            for (int i = 0; i < _questions.Count; i++)
            {
                bool correct = _userAnswers[i] == _questions[i].CorrectAnswerIndex;
                int  rowH    = correct ? 54 : 96;

                var row = new Panel
                {
                    Location=new Point(0,y), Size=new Size(646,rowH),
                    BackColor=correct?Color.FromArgb(232,248,238):Color.FromArgb(255,238,238)
                };
                bool rc = correct;
                row.Paint += (s,e) =>
                {
                    using var pen = new System.Drawing.Pen(
                        rc?Color.FromArgb(160,215,175):Color.FromArgb(215,175,175),1);
                    e.Graphics.DrawRectangle(pen,0,0,row.Width-1,row.Height-1);
                };

                row.Controls.Add(new Label { Text=correct?"✔":"✖",
                    ForeColor=correct?Color.FromArgb(25,130,65):Color.FromArgb(185,38,38),
                    Font=new Font("Segoe UI",13f,FontStyle.Bold),
                    Location=new Point(8,0), Size=new Size(30,rowH),
                    TextAlign=ContentAlignment.MiddleCenter });
                row.Controls.Add(new Label { Text=$"Q{i+1}",
                    ForeColor=correct?Color.FromArgb(25,130,65):Color.FromArgb(185,38,38),
                    Font=new Font("Segoe UI",8f,FontStyle.Bold),
                    Location=new Point(44,8), Size=new Size(38,16) });
                row.Controls.Add(new Label { Text=_questions[i].QuestionText,
                    ForeColor=Color.FromArgb(25,25,25),
                    Font=new Font("Segoe UI",9.5f,FontStyle.Bold),
                    Location=new Point(44,26), Size=new Size(592,correct?22:20),
                    TextAlign=ContentAlignment.MiddleLeft });

                if (!correct)
                {
                    string ua = _userAnswers[i]>=0
                        ? $"{L[_userAnswers[i]]})  {_questions[i].Options[_userAnswers[i]]}"
                        : "No answer";
                    string ca = $"{L[_questions[i].CorrectAnswerIndex]})  {_questions[i].Options[_questions[i].CorrectAnswerIndex]}";

                    row.Controls.Add(new Label { Text="Your answer:",
                        ForeColor=Color.FromArgb(140,60,60), Font=new Font("Segoe UI",8.5f,FontStyle.Bold),
                        Location=new Point(44,50), Size=new Size(110,18) });
                    row.Controls.Add(new Label { Text=ua,
                        ForeColor=Color.FromArgb(180,45,45), Font=new Font("Segoe UI",8.5f),
                        Location=new Point(158,50), Size=new Size(478,18) });
                    row.Controls.Add(new Label { Text="Correct answer:",
                        ForeColor=Color.FromArgb(20,100,50), Font=new Font("Segoe UI",8.5f,FontStyle.Bold),
                        Location=new Point(44,72), Size=new Size(110,18) });
                    row.Controls.Add(new Label { Text=ca,
                        ForeColor=Color.FromArgb(20,110,55), Font=new Font("Segoe UI",8.5f,FontStyle.Bold),
                        Location=new Point(158,72), Size=new Size(478,18) });
                }

                scroll.Controls.Add(row);
                y += rowH + 6;
            }

            Controls.Add(scroll);
            Controls.Add(pnlFooter);
            Controls.Add(pnlRevHdr);
            Controls.Add(pnlHeader);
        }
    }
}
