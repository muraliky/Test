using System;
using System.IO;
using System.Threading;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using System.Drawing;

namespace QuizApp
{
    public static class ExcelScoreWriter
    {
        // Columns: S.No | Full Name | Score | Total | Percentage | Time Taken (sec) | Time Display | Submitted At
        private static readonly string[] Headers =
        {
            "S.No", "Full Name", "Score", "Total",
            "Percentage", "Time Taken (sec)", "Time Display", "Submitted At"
        };
        private const int COL_COUNT  = 8;
        private const int MAX_RETRY  = 5;
        private const int RETRY_MS   = 600;

        // ── Write score with retry on file-lock ───────────────────────
        public static void WriteScore(string masterPath, string fullName,
                                      int score, int total,
                                      DateTime timestamp, int timeTakenSeconds)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            var fileInfo = new FileInfo(masterPath);
            if (!Directory.Exists(fileInfo.DirectoryName))
                Directory.CreateDirectory(fileInfo.DirectoryName);

            Exception lastEx = null;
            for (int attempt = 1; attempt <= MAX_RETRY; attempt++)
            {
                try
                {
                    WriteToFile(fileInfo, fullName, score, total, timestamp, timeTakenSeconds);

                    // Success — now copy master → dashboard copy
                    CopyToDashboard(masterPath);
                    return;
                }
                catch (IOException ex)
                {
                    lastEx = ex;
                    if (attempt < MAX_RETRY)
                        Thread.Sleep(RETRY_MS * attempt);   // back-off: 600ms, 1200ms, 1800ms…
                }
            }
            throw new IOException(
                $"Could not write to Excel after {MAX_RETRY} attempts: {lastEx?.Message}");
        }

        // ── Core write logic ──────────────────────────────────────────
        private static void WriteToFile(FileInfo fileInfo, string fullName,
                                        int score, int total,
                                        DateTime timestamp, int timeTakenSeconds)
        {
            using var package = fileInfo.Exists
                ? new ExcelPackage(fileInfo)
                : new ExcelPackage();

            ExcelWorksheet ws;
            if (fileInfo.Exists && package.Workbook.Worksheets.Count > 0)
                ws = package.Workbook.Worksheets[0];
            else
            {
                ws = package.Workbook.Worksheets.Add("Quiz Scores");
                CreateHeader(ws);
            }

            int row = ws.Dimension?.End.Row + 1 ?? 3;
            if (row < 3) row = 3;

            double pct = total > 0 ? Math.Round((double)score / total * 100, 1) : 0;

            ws.Cells[row, 1].Value = row - 2;
            ws.Cells[row, 2].Value = fullName;
            ws.Cells[row, 3].Value = score;
            ws.Cells[row, 4].Value = total;
            ws.Cells[row, 5].Value = pct / 100.0;
            ws.Cells[row, 5].Style.Numberformat.Format = "0.0%";
            ws.Cells[row, 6].Value = timeTakenSeconds;
            ws.Cells[row, 7].Value = FormatTime(timeTakenSeconds);
            ws.Cells[row, 8].Value = timestamp.ToString("dd-MMM-yyyy HH:mm:ss");

            Color rowColor = pct >= 80 ? Color.FromArgb(198, 239, 206)
                           : pct >= 60 ? Color.FromArgb(255, 235, 156)
                                       : Color.FromArgb(255, 199, 206);
            using var range = ws.Cells[row, 1, row, COL_COUNT];
            range.Style.Fill.PatternType = ExcelFillStyle.Solid;
            range.Style.Fill.BackgroundColor.SetColor(rowColor);
            range.Style.Border.Bottom.Style = ExcelBorderStyle.Thin;
            range.Style.Border.Bottom.Color.SetColor(Color.LightGray);

            foreach (int c in new[] { 1, 3, 4, 5, 6 })
                ws.Cells[row, c].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;

            ws.Cells[ws.Dimension.Address].AutoFitColumns();
            package.SaveAs(fileInfo);
        }

        // ── Copy master → dashboard file ──────────────────────────────
        private static void CopyToDashboard(string masterPath)
        {
            string dir      = Path.GetDirectoryName(masterPath);
            string name     = Path.GetFileNameWithoutExtension(masterPath);
            string ext      = Path.GetExtension(masterPath);
            string dashPath = Path.Combine(dir, name + "_Dashboard" + ext);

            // Retry the copy too — dashboard script may be reading it
            for (int i = 0; i < MAX_RETRY; i++)
            {
                try
                {
                    File.Copy(masterPath, dashPath, overwrite: true);
                    return;
                }
                catch (IOException)
                {
                    if (i < MAX_RETRY - 1)
                        Thread.Sleep(RETRY_MS);
                }
            }
            // Non-fatal if copy fails — master is safe
        }

        // ── Check for duplicate name ──────────────────────────────────
        public static bool NameExists(string filePath, string fullName)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var fileInfo = new FileInfo(filePath);
            if (!fileInfo.Exists) return false;

            try
            {
                using var package = new ExcelPackage(fileInfo);
                if (package.Workbook.Worksheets.Count == 0) return false;
                var ws      = package.Workbook.Worksheets[0];
                int lastRow = ws.Dimension?.End.Row ?? 2;
                for (int r = 3; r <= lastRow; r++)
                {
                    var cell = ws.Cells[r, 2].Value?.ToString()?.Trim();
                    if (string.Equals(cell, fullName.Trim(),
                        StringComparison.OrdinalIgnoreCase)) return true;
                }
            }
            catch { /* file locked — assume no duplicate, let submit proceed */ }

            return false;
        }

        // ── Helpers ───────────────────────────────────────────────────
        private static void CreateHeader(ExcelWorksheet ws)
        {
            ws.Cells[1, 1, 1, COL_COUNT].Merge = true;
            ws.Cells[1, 1].Value = "Quiz Score Tracker";
            ws.Cells[1, 1].Style.Font.Bold = true;
            ws.Cells[1, 1].Style.Font.Size = 14;
            ws.Cells[1, 1].Style.Font.Color.SetColor(Color.White);
            ws.Cells[1, 1].Style.Fill.PatternType = ExcelFillStyle.Solid;
            ws.Cells[1, 1].Style.Fill.BackgroundColor.SetColor(Color.FromArgb(31, 78, 121));
            ws.Cells[1, 1].Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
            ws.Row(1).Height = 30;

            for (int i = 0; i < Headers.Length; i++)
            {
                var cell = ws.Cells[2, i + 1];
                cell.Value = Headers[i];
                cell.Style.Font.Bold = true;
                cell.Style.Font.Color.SetColor(Color.White);
                cell.Style.Fill.PatternType = ExcelFillStyle.Solid;
                cell.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(31, 78, 121));
                cell.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                cell.Style.Border.BorderAround(ExcelBorderStyle.Thin, Color.White);
            }
            ws.Row(2).Height = 22;
            ws.View.FreezePanes(3, 1);
        }

        public static string FormatTime(int seconds)
        {
            if (seconds < 60) return $"{seconds}s";
            int m = seconds / 60, s = seconds % 60;
            return s == 0 ? $"{m}m" : $"{m}m {s}s";
        }
    }
}
